extole.define([
    'core-root:///common/server/variable-manager.js'
], function (
    variableManager
) {
    'use strict';

    return function (creativeBuilder, variableBuilder, variablesToWrite, campaignBuilder, jsCampaign) {
        variableManager.writeVariables(creativeBuilder, variableBuilder, variablesToWrite, campaignBuilder, jsCampaign);
    };

});
