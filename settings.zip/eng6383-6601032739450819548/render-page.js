extole.define([
    'core-root:///common/server/template-service.js',
    '_shared-assets/js/variable-manager.js'
], function (templateService, variableManager) {
    'use strict';

    return function (builder, context) {
        templateService.loadEncoderService(context);
        var variables = variableManager.getVariables(context);
        builder.setStatus(200);
	builder.setHeader("Content-Type", "application/json");
        builder.setBody(JSON.stringify(variables));
    };

});
