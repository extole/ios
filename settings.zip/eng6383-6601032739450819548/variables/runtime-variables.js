extole.define([
    'core-root:///common/server/variable-definitions.js'
], function (variableDefinitions) {
    'use strict';

    return [
        {
            name: 'coreJsUrl',
            label: 'Core.js URL',
            implementation: function (context) {
                return '//' + context.getProgram().getProgramDomain().replace(/^https?:|\/\/|\/+$/gi, '') + '/core.js';
            }
        },
        {
            name: 'shareExperienceData',
            label: 'Share Experience Data',
            implementation: function (context) {
                var nashhornMap = context.getParameters();
                var parametersForShareExperience = {
                    widgetIsEmbedded: true
                };

                for (var key in nashhornMap) {
                    parametersForShareExperience[key] = nashhornMap[key];
                }

                if (!context.getCoreConfig().backendTargetingEnabled() && !parametersForShareExperience.campaign_id) {
                    parametersForShareExperience.campaign_id = context.getCampaign().getId();
                }

                return JSON.stringify(parametersForShareExperience);
            }
        },
        {
            name: 'isShowStats',
            label: 'Show Stats',
            implementation: function (context) {
                var displayEmbeddedStats = variableDefinitions.getStaticVariable('displayEmbeddedStats', context);
                var parameters = context.getParameters();
                var isStats = parameters.show_stats || parameters.is_stats || parameters.showStats || parameters.isStats;
                return (Boolean(displayEmbeddedStats) && displayEmbeddedStats !== 'false') || (Boolean(isStats) && isStats !== 'false');
            }
        },
        {
            name: 'currentYear',
            label: 'Current Year',
            implementation: function (context) {
                return new Date().getFullYear();
            }
        }
    ];

});
