extole.define([
    'core-root:///common/server/template-service.js',
    'core-root:///common/server/variable-manager.js',
    'variables/runtime-variables.js'
], function (
    templateService,
    variableManager,
    runtimeVariables
) {
    'use strict';

    return function (builder, context) {
        templateService.loadEncoderService(context);
        var variables = variableManager.getVariables(context, runtimeVariables);
        var parameters = context.getParameters();
        var template = context.openFile('html/template.html').getContent();
        var htmlBody = templateService.render(template, variables);

        if (parameters.close) {
            template = context.openFile('html/close.html').getContent();
            htmlBody = templateService.render(template, variables);
        }

        if (variables.denyFramingForCreativePages) {
            builder.setHeader("X-Frame-Options","ALLOW-FROM https://*.extole.com");
            builder.setHeader("Content-Security-Policy", "frame-ancestors https://*.extole.com");
        }

        builder.setStatus(200);
        builder.setBody(htmlBody);
    };

});
