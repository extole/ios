extole.define([
    '_shared-assets/js/variable-manager.js'
], function (
    variableManager
) {
    'use strict';

    return function (creativeBuilder, variableBuilder, variablesToWrite) {
        variableManager.writeVariableDeclarations(creativeBuilder, variableBuilder, variablesToWrite);
    };

});
