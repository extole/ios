extole.define([
    '_shared-assets/js/variable-manager.js'
], function (
    variableManager
) {
    'use strict';

    return function (variableBuilder, creativeContext) {
        variableManager.readVariableDeclarations(variableBuilder, creativeContext);
    };

});
