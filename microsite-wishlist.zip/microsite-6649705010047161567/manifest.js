extole.define([], function () {
    "use strict";

    return {
        "name" : "Classic Microsite",
        "tags": ["microsite"],
        "api_version": "5",
        "theme_version": "1.125.0.1574-20190118"
    };
});
