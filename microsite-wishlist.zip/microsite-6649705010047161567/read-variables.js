extole.define([
    'core-root:///common/server/variable-manager.js',
    'variables/runtime-variables.js'
], function (
    variableManager,
    runtimeImplementations
) {
    'use strict';

    return function (variableBuilder, creativeContext, jsCampaign) {
        variableManager.readVariables(variableBuilder, creativeContext, jsCampaign, runtimeImplementations);
    };

});
