extole.define([], function () {
    "use strict";

    return {
        "name" : "Classic Microsite",
        "tags": ["microsite"],
        "api_version": "5",
        "theme_version": "1.116.8.1440-20180709"
    };
});
