extole.define([
    'core-root:///common/server/template-service.js',
    'variables/runtime-variables.js'
], function (templateService, runtimeVariableImplementations) {
    'use strict';

    var STATIC_VARIABLE_FILE = 'variables/static-variables.json';
    var VARIABLE_STRING_TYPE = 'text';
    var RUNTIME_VARIABLES_ARE_VISIBLE = false;
    var TEMPLATE_ESCAPED_TAGS = /{{(?!\s*safe\w+\()([^}]+)}}/gi;
    var TEMPLATE_NOT_ESCAPED_TAGS = /{{{([^}]+)}}}/g;
    var TEMPLATE_SAFE_TAGS = /{{\s*safe\w+\(([^\)]+)\)\s*}}/gi;

    function VariableManager() {

        function getVariables(context) {
            templateService.loadEncoderService(context);

            var runtimeObjects = {};
            var staticDeclarations = JSON.parse(context.openFile(STATIC_VARIABLE_FILE).getContent());
            var runtimeDeclarations = implementRuntimeVariables();
            var resolvedVariableDeclarations = resolveVariableDeclarations();
            var variables = resolvedVariableDeclarations.reduce(variableToHash, {});

            return variables;

            function implementRuntimeVariables() {
                return assertRuntimeImplementations(runtimeVariableImplementations).map(createVariableDeclaration);

                function createVariableDeclaration(variable) {
                    var variableName = variable.name;
                    var variableValue = variable.implementation(context) || '';
                    var variableType = typeof variableValue === 'string' ? VARIABLE_STRING_TYPE : 'RUNTIME';

                    if (isJavascriptObject(variableValue)) {
                        runtimeObjects[variableName] = variableValue;
                    }

                    return {
                        name: variableName,
                        type: variableType,
                        value: variableValue,
                        visible: RUNTIME_VARIABLES_ARE_VISIBLE
                    };
                }
            }

            function resolveVariableDeclarations() {
                var originalDeclarations = staticDeclarations.concat(runtimeDeclarations);
                var combinedVariablesDeclarations = assertVariableDeclarations(originalDeclarations);

                combinedVariablesDeclarations.forEach(resolveVariable);

                return combinedVariablesDeclarations;

                function resolveVariable(variable) {
                    if (isTextVariable(variable)) {
                        variable.value = renderTextTypeValue(variable.value.toString(), variable.name);
                    }

                    Object.defineProperty(variable, 'resolved', {
                        enumerable: false,
                        value: true
                    });
                }

                function renderTextTypeValue(variableValue, variableName) {
                    var interpolatedVariableNames = getInterpolatedVariableNames(variableValue);
                    var resolvedVariables = getResolvedVariablesByNames(interpolatedVariableNames);
                    var variablesAsHash = resolvedVariables.reduce(variableToHash, runtimeObjects);

                    try {
                        return templateService.renderUnencoded(variableValue, variablesAsHash);
                    } catch (error) {
                        print(['templateService error compiling variable value as a template: ',
                            'variable name: ' + variableName + ', ',
                            'variable value: ' + variableValue + ', ',
                            'error stack: ' + error.message, error].join('\n')
                        );
                        return variableValue;
                    }
                }

                function getResolvedVariablesByNames(variableNames) {
                    var matchedVariables = getVariablesByNames(combinedVariablesDeclarations, variableNames);

                    return matchedVariables.filter(function (variable) {
                        if (variable && !variable.resolved) {
                            resolveVariable(variable);
                        }
                        return variable;
                    });
                }
            }
        }

        function readVariableDeclarations(builder, context) {
            var staticDeclarations = JSON.parse(context.openFile(STATIC_VARIABLE_FILE).getContent());

            staticDeclarations.concat(runtimeVariableImplementations).forEach(function (variable) {
                builder.addVariable()
                    .setName(variable.name)
                    .setLabel(variable.label)
                    .setDefaultValue(variable.defaultValue)
                    .setValue(variable.value)
                    .setScope(variable.scope)
                    .setDefaultScope(variable.defaultScope)
                    .setType(variable.type)
                    .setVisible(variable.visible);
            });
        }

        function writeVariableDeclarations(creativeBuilder, variableBuilder, variablesToWrite) {
            var variablesFile = creativeBuilder.openFile(STATIC_VARIABLE_FILE);
            var variables = JSON.parse(variablesFile.getContent());

            updateVariables(variables, variablesToWrite);

            try {
                checkForCircularDependencies(variables);
            } catch (error) {
                if (error.code === 'CIRCULAR_DEPENDENCY_ERROR') {
                    print('ERROR circular dependency in variables:' +
                        ' variableName: ' + error.context.variableName +
                        ' dependencyChain: ' + error.context.dependencyChain
                    );
                } else {
                    print('ERROR while checking for circular dependencies between variables.' + error.stack);
                }

                return;
            }

            variablesFile.setContent(JSON.stringify(variables));

            function updateVariables(variables, variablesToWrite) {
                for (var i = 0; i < variablesToWrite.length; i++) {
                    var variableToWrite = variablesToWrite[i];
                    var matchedVariable = getVariableByName(variables, variableToWrite.getName());

                    if (matchedVariable) {
                        matchedVariable.scope = variableToWrite.getScope();
                        matchedVariable.value = checkValueForTrueFalse(variableToWrite.getValue());
                    } else {
                        print('DEBUG - variable to write not found by name: ' + variableToWrite.getName());
                    }
                }

                function checkValueForTrueFalse(value) {
                    value = value === 'true' ? true : value;
                    value = value === 'false' ? false : value;
                    return value;
                }
            }

            function checkForCircularDependencies(variableList) {
                var dependencyChain = [];

                variableList.filter(isTextVariable).forEach(_checkForCircularDependencies);

                function _checkForCircularDependencies(variable) {
                    if (dependencyChain.indexOf(variable.name) > -1) {
                        return throwErorrFor(variable.name, dependencyChain);
                    }

                    dependencyChain.push(variable.name);

                    var interpolatedVariableNames = getInterpolatedVariableNames(variable.value);
                    var interpolatedVariables = getVariablesByNames(variableList, interpolatedVariableNames);

                    interpolatedVariables.forEach(_checkForCircularDependencies);

                    dependencyChain.pop();
                }

                function throwErorrFor(variableName, dependencyChain) {
                    var circularDependencyError = new Error('ERROR: circular dependency for ' + variableName);
                    circularDependencyError.code = 'CIRCULAR_DEPENDENCY_ERROR';
                    circularDependencyError.context = {
                        variableName: variableName,
                        dependencyChain: dependencyChain.concat(variableName)
                    };

                    throw circularDependencyError;
                }
            }
        }

        function assertRuntimeImplementations(runtimeImplementations) {
            runtimeImplementations.forEach(function (variable) {
                assert(isJavascriptObject(variable), 'Runtime variable expects to be plain JS object');
                assert(typeof variable.name === 'string', 'Runtime variable expects property "name" string');
                assert(typeof variable.implementation === 'function', 'Runtime variable expects "implementation"');
            });
            return runtimeImplementations;
        }

        function assertVariableDeclarations(variables) {
            variables.forEach(function (variable) {
                var errorMessage = 'Variable expects name and value: ' + JSON.stringify(variable);
                assert(typeof variable.name !== 'undefined', errorMessage);
                assert(typeof variable.value !== 'undefined', errorMessage);
            });
            return deepDuplicate(variables);
        }

        function assert(condition, message) {
            if (!condition) {
                throw new Error(message || 'Assertion failed');
            }
        }

        function getInterpolatedVariableNames(string) {
            var notEscapedVariables = getInterpolateVariablesByTags(string, TEMPLATE_NOT_ESCAPED_TAGS);
            var escapedVariables = getInterpolateVariablesByTags(string, TEMPLATE_ESCAPED_TAGS);
            var safeVariables = getInterpolateVariablesByTags(string, TEMPLATE_SAFE_TAGS);

            return notEscapedVariables.concat(escapedVariables, safeVariables);
        }

        function getInterpolateVariablesByTags(string, tag) {
            var interpolatedVariables = string.match(tag) || [];

            return interpolatedVariables.map(function (variable) {
                return variable.replace(tag, '$1').trim();
            });
        }

        function getVariablesByNames(variables, variableNames) {
            return variables.filter(function (variable) {
                return variableNames.indexOf(variable.name) > -1;
            });
        }

        function getVariablesByTag(context, tagName) {
            var staticVariables = JSON.parse(context.openFile(STATIC_VARIABLE_FILE).getContent());
            var variables = staticVariables.concat(runtimeVariableImplementations.map(createVariableDeclaration)).filter(hasTags(tagName));

            return variables;

            function createVariableDeclaration(variable) {
                var variableName = variable.name;
                var variableValue = variable.implementation(context) || '';
                var variableTags = variable.tags;

                return {
                    name: variableName,
                    tags: variableTags,
                    value: variableValue
                };
            }

            function hasTags(tagName) {
                return function(variable) {
                    return variable.tags && variable.tags.indexOf(tagName) > -1;
                }
            }
        }

        function getVariableByName(variables, targetName) {
            return getVariablesByNames(variables, [targetName]).shift() || null;
        }

        function isTextVariable(variable) {
            return variable.type && variable.type.toLowerCase() === VARIABLE_STRING_TYPE;
        }

        function variableToHash(accumulator, variable) {
            accumulator[variable.name] = variable.value;
            return accumulator;
        }

        function deepDuplicate(jsonifiableObject) {
            return JSON.parse(JSON.stringify(jsonifiableObject));
        }

        function isJavascriptObject(variable) {
            return Object.prototype.toString.call(variable) === '[object Object]';
        }

        this.getVariables = getVariables;
        this.getVariablesByTag = getVariablesByTag;
        this.readVariableDeclarations = readVariableDeclarations;
        this.writeVariableDeclarations = writeVariableDeclarations;

    }

    return new VariableManager();

});
